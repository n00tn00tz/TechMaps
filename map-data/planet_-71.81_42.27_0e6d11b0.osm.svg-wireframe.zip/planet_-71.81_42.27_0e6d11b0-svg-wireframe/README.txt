Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
Maperitive by http://maperitive.net/

Please read the OSM wiki how to use SVG

  https://en.wikipedia.org/wiki/Scalable_Vector_Graphics
  https://wiki.openstreetmap.org/wiki/SVG


This SVG map was created on: Sun 15 Dec 21:45:20 UTC 2024
Maperitive map style: wireframe
GPS rectangle coordinates (lng,lat): -71.816,42.27 x -71.798,42.278
Script URL: https://extract.bbbike.org/?sw_lng=-71.816&sw_lat=42.27&ne_lng=-71.798&ne_lat=42.278&format=svg-wireframe.zip&coords=-71.81%2C42.27%7C-71.803%2C42.27%7C-71.798%2C42.27%7C-71.798%2C42.274%7C-71.799%2C42.278%7C-71.808%2C42.278%7C-71.816%2C42.27&city=WPI&lang=en
Name of area: WPI


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 20 Euro (25 USD) by the end of the day or
600 Euro (700 USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
